$(document).ready(function(){
	

	$('.bxslider').bxSlider({
		'auto':true
	});


});